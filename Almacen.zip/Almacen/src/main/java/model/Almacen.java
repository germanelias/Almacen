package model;

public class Almacen {
    private int idbebida;
    private String articulo;
    private String marca;
    private String presentacion;
    private double precio;
    private int stock;

    public Almacen(int idbebida, String articulo, String marca, String presentacion, double precio, int stock) {
        this.idbebida = idbebida;
        this.articulo = articulo;
        this.marca = marca;
        this.presentacion = presentacion;
        this.precio = precio;
        this.stock = stock;
    }

    public Almacen(String articulo, String marca, String presentacion, double precio, int stock) {
        this.articulo = articulo;
        this.marca = marca;
        this.presentacion = presentacion;
        this.precio = precio;
        this.stock = stock;
    }

    public int getIdbebida() {
        return idbebida;
    }

    public void setIdbebida(int idbebida) {
        this.idbebida = idbebida;
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }
    
    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Bebida{" + "articulo=" + articulo + ", marca=" + marca + ", presentacion=" + presentacion + ", precio=" + precio + ", stock=" + stock + '}';
    }
}
