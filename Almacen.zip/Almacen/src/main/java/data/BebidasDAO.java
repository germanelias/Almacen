package data;

import static data.Conexion.*;
import java.sql.*;
import java.util.*;
import model.Almacen;

public class BebidasDAO {
    private static final String SQL_CREATE="INSERT INTO bebidas(articulo, marca, presentacion, precio, stock) VALUES(?, ?, ?, ?, ?)";
    private static final String SQL_READ="SELECT * FROM bebidas";
    private static final String SQL_READ_BY_ID= "SELECT * FROM bebidas WHERE idbebidas= ?";
    private static final String SQL_UPDATE_PRECIO="UPDATE bebidas SET precio = ? WHERE idbebidas = ?";
    private static final String SQL_UPDATE_STOCK="UPDATE bebidas SET stock = ? WHERE idbebidas = ?";
    private static final String SQL_UPDATE="UPDATE bebidas SET articulo = ?, marca = ?, presentacion = ?, precio = ?,stock = ? WHERE idbebidas = ?";
    private static final String SQL_DELETE="DELETE FROM bebidas WHERE idbebidas = ?";
    
    
    public List<Almacen> findAll() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Almacen bebida ;
        List<Almacen> bebidas = new ArrayList();

        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_READ);
            rs = stmt.executeQuery();
            while (rs.next()) {
                
                int idbebidas = rs.getInt(1);
                String articulo = rs.getString(2);
                String marca = rs.getString(3);
                String presentacion = rs.getString(4);
                double precio = rs.getDouble(5);
                int stock = rs.getInt(6);

                bebida = new Almacen(idbebidas, articulo, marca, presentacion, precio, stock);

                bebidas.add(bebida);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                close(rs);
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }

        return bebidas;
    }
    
    public Almacen findById(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Almacen bebida = null;
        
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_READ_BY_ID);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                int idbebidas = rs.getInt(1);
                String articulo = rs.getString(2);
                String marca = rs.getString(3);
                String presentacion = rs.getString(4);
                double precio = rs.getDouble(5);
                int stock = rs.getInt(6);

                bebida = new Almacen(idbebidas, articulo, marca, presentacion, precio, stock);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                close(rs);
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return bebida;
    }
    
    
    
    public int insert(Almacen bebida){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_CREATE);
            stmt.setString(1, bebida.getArticulo());
            stmt.setString(2, bebida.getMarca());
            stmt.setString(3, bebida.getPresentacion());
            stmt.setDouble(4, bebida.getPrecio());
            stmt.setInt(5, bebida.getStock());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int updatePrecio(Almacen bebida){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE_PRECIO);
            stmt.setDouble(1, bebida.getPrecio());
            stmt.setInt(2, bebida.getIdbebida());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int updateStock(Almacen bebida){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE_STOCK);
            stmt.setInt(1, bebida.getStock());
            stmt.setInt(2, bebida.getIdbebida());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int update(Almacen bebida){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, bebida.getArticulo());
            stmt.setString(2, bebida.getMarca());
            stmt.setString(3, bebida.getPresentacion());
            stmt.setDouble(4, bebida.getPrecio());
            stmt.setInt(5, bebida.getStock());
            stmt.setInt(6, bebida.getIdbebida());
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
    
    public int deleteBebida(int id){
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = getConexion();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, id);
            registros = stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            try {
                close(stmt);
                close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }
}
